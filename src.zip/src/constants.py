from pyftg_sound.openal import al

source_attrs = {
    al.AL_ROLLOFF_FACTOR: 0.01
}